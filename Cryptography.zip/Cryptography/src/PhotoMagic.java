/*Kevin Paul, 4B*/

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;

public class PhotoMagic {
    public static Picture transform(Picture pic, LFSR lfsr) {
        Picture newPic = new Picture(pic.width(), pic.height());

        for (int row = 0; row < pic.height(); row++)
            for (int col = 0; col < pic.width(); col++) {
                Color rgb = pic.get(col, row);

                int lfsrVal = lfsr.generate(8);
                String lfsrBits = Integer.toBinaryString(lfsrVal);
                while (lfsrBits.length() < 8)
                    lfsrBits = "0" + lfsrBits;

                //encrypting red value
                int redVal = rgb.getRed();

                String redBits = Integer.toBinaryString(redVal);

                while (redBits.length() < 8)
                    redBits = "0" + redBits;

                String encryptedRedStr = "";
                for (int i = 0; i < 8; i++) {
                    if (!redBits.substring(i, i + 1).equals(lfsrBits.substring(i, i + 1)))
                        encryptedRedStr += 1;
                    else
                        encryptedRedStr += 0;
                }

                int encryptedRedVal = 0;
                int j = 7;
                for (int i = 0; i < 8; i++) {
                    encryptedRedVal += Math.pow(2, j) * Integer.parseInt(encryptedRedStr.substring(i, i + 1));
                    j--;
                }

                lfsrVal = lfsr.generate(8);
                lfsrBits = Integer.toBinaryString(lfsrVal);
                while (lfsrBits.length() < 8)
                    lfsrBits = "0" + lfsrBits;

                //encrypting green value
                int greenVal = rgb.getGreen();

                String greenBits = Integer.toBinaryString(greenVal);

                while (greenBits.length() < 8)
                    greenBits = "0" + greenBits;

                String encryptedGreenStr = "";
                for (int i = 0; i < 8; i++) {
                    if (!greenBits.substring(i, i + 1).equals(lfsrBits.substring(i, i + 1)))
                        encryptedGreenStr += 1;
                    else
                        encryptedGreenStr += 0;
                }

                int encryptedGreenVal = 0;
                j = 7;
                for (int i = 0; i < 8; i++) {
                    encryptedGreenVal += Math.pow(2, j) * Integer.parseInt(encryptedGreenStr.substring(i, i + 1));
                    j--;
                }

                lfsrVal = lfsr.generate(8);
                lfsrBits = Integer.toBinaryString(lfsrVal);
                while (lfsrBits.length() < 8)
                    lfsrBits = "0" + lfsrBits;

                //encrypting blue value
                int blueVal = rgb.getBlue();

                String blueBits = Integer.toBinaryString(blueVal);

                while (blueBits.length() < 8)
                    blueBits = "0" + blueBits;

                String encryptedBlueStr = "";
                for (int i = 0; i < 8; i++) {
                    if (!blueBits.substring(i, i + 1).equals(lfsrBits.substring(i, i + 1)))
                        encryptedBlueStr += 1;
                    else
                        encryptedBlueStr += 0;
                }

                int encryptedBlueVal = 0;
                j = 7;
                for (int i = 0; i < 8; i++) {
                    encryptedBlueVal += Math.pow(2, j) * Integer.parseInt(encryptedBlueStr.substring(i, i + 1));
                    j--;
                }

                Color encrypted_rgb = new Color(encryptedRedVal, encryptedGreenVal, encryptedBlueVal);
                newPic.set(col, row, encrypted_rgb);
            }


        return newPic;
    }

    public static void main(String[] args) throws FileNotFoundException {
        LFSR lfsr = new LFSR("01101000010100010000", 16);
        Picture pic = new Picture(new File("pipe.png"));
        pic.show();

        //encrypts the pic
        Picture encryptedPic = transform(pic, lfsr);
        encryptedPic.show();

        lfsr = new LFSR("01101000010100010000", 16);
        transform(encryptedPic, lfsr).show(); //decrypts the encrypted pic
    }
}
