import javax.swing.*;
import java.awt.Color;
import java.awt.Font;

public class GemList
{
	public static void main(String [] args) {
		GemList list = new GemList();
		System.out.println(list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.9);

		list.insertBefore(new Gem(GemType.BLUE, 10), 0);
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.8);

		list.insertBefore(new Gem(GemType.BLUE, 20), 99);  //not a mistake, should still work
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.7);

		list.insertBefore(new Gem(GemType.ORANGE, 30), 1);
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.6);

		list.insertBefore(new Gem(GemType.ORANGE, 10), 2);
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.5);

		list.insertBefore(new Gem(GemType.ORANGE, 50), 3);
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.4);

		list.insertBefore(new Gem(GemType.GREEN, 50), 2);
		System.out.println("\n" + list);
		System.out.println("size = " + list.size() + ", score = " + list.score());
		list.draw(0.3);
	}

	private Node head;
	private int size;

	public GemList() {
		head = null;
		size = 0;
	}

	public void addToFront(Gem gem) {
		Node previousHead = head;
		head = new Node(gem);
		head.setNext(previousHead);
		size++;
	}

	public void addToBack(Gem gem) {
		Node newNode = new Node(gem);
		Node current = head;
		while (current.getNext() != null)
			current = (Node) current.getNext();
		current.setNext(newNode);
		size++;
	}

	public Object get(int index) {
		if (head.equals(null))
			return null;
		else {
			Node current = head;
			for (int i = 0; i < size; i++) {
				if(i == index)
					return current.get();
				current = (Node) current.getNext();
			}
			return null;
		}
	}

	public int size() { return size; }

	@Override
	public String toString() {
		String list = "";
		for (int i = 0; i < size; i++) {
			list += get(i).toString() + "\n";
		}
		list += " Score: " + Integer.toString(score());
		return list;
	}

	public void insertBefore(Gem gem, int index) {
		if (size() == 0)
			addToFront(gem);
		else if (index >= size)
			addToBack(gem);
		else {
			Node newNode = new Node(gem);
			Node current = head;
			for (int i = 0; i < index - 1; i++)
				current = (Node) current.getNext();
			newNode.setNext((Node) current.getNext());
			current.setNext(newNode);
			size++;
		}
	}

	public int score() {
		if(size() == 0)
			return 0;
		else if(size() == 1)
			return ((Gem) head.get()).getPoints();

		int score = 0, chainScore = 0, chain = 0;
		Node current = head;
		GemType type = ((Gem) current.get()).getType(), gemType;
		chainScore += ((Gem) current.get()).getPoints();
		chain++;
		for (int i = 1; i < size(); i++) {
			current = (Node) current.getNext();
			gemType = ((Gem) current.get()).getType();
			if (type != gemType) {
				score += chainScore * chain;
				chain = 1;
				chainScore = ((Gem) current.get()).getPoints();
				type = gemType;
			} else {
				chainScore += ((Gem) current.get()).getPoints();
				chain++;
				type = gemType;
			}
		}
		score += chain * chainScore;
		return score;
	}

	public void draw(double y){
		Node current = head;
		for (int i = 0; i < size(); i++) {
			GemType type = ((Gem) current.get()).getType();
			if(type == GemType.GREEN) {
				StdDraw.picture(0.07 * i + 0.03, y, "gem_green.png");
			} else if (type == GemType.BLUE) {
				StdDraw.picture(0.07 * i + 0.03, y, "gem_blue.png");
			} else {
				StdDraw.picture(0.07 * i + 0.03, y, "gem_orange.png");
			}

			StdDraw.setFont(new Font("SansSerif", Font.BOLD, 14));
			StdDraw.setPenColor(Color.WHITE);
			StdDraw.text(0.07 * i + 0.03, y, Integer.toString(((Gem) current.get()).getPoints()));
			current = (Node) current.getNext();
		}
	}
}
