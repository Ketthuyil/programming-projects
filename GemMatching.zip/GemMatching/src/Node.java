/*Kevin Paul, 4B, 11/20/19*/

public class Node {
    private Gem gem;
    private Node next;

    Node() {
        gem = null;
        next = null;
    }

    Node(Gem gem) {
        this.gem = gem;
        next = null;
    }

    Object get() { return gem; }

    public void set(Gem gem) { this.gem = gem; }

    public Object getNext() { return next; }

    public void setNext(Node next) { this.next = next; }

    @Override
    public String toString() {
        return "{Gem: " + gem + "}";
    }
}