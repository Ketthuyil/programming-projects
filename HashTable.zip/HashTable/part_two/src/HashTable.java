/*Kevin Paul, 4B, 12/2/19*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class HashTable {
    private int initCap, size = 0;
    private Entry[] set;

    HashTable() {
        initCap = 101;
        set = new Entry[initCap];
    }

    HashTable(int initCap) {
        this.initCap = initCap;
        set = new Entry[initCap];
    }

    Object put(Object key, Object value) {
        int hc = key.hashCode(), index = hc % initCap;

        if (size < initCap) {
            if (set[index] == null) {
                set[index] = new Entry(key, value);
                size++;
                return null;
            } else if (set[index].removed) {
                Entry prevEntry = set[index];
                set[index] = new Entry(key, value);
                return prevEntry.value;
            } else if (set[index].key.equals(key)) {
                Object prevValue = set[index].value;
                set[index] = new Entry(key, value);
                return prevValue;
            } else {
                int offset = 1;

                while (offset < initCap) {
                    if (set[(index + offset) % initCap] == null) {
                        set[(index + offset) % initCap] = new Entry(key, value);
                        size++;
                        return null;
                    } else if (set[(index + offset) % initCap].removed) {
                        set[(index + offset) % initCap] = new Entry(key, value);

                        offset++;
                        while (index + offset < initCap) {
                            if (set[(index + offset) % initCap] == null) {
                                size++;
                                return null;
                            } else if (set[(index + offset) % initCap].key.equals(key)) {
                                set[(index + offset) % initCap].removed = true;
                                return set[(index + offset) % initCap].value;
                            }
                            offset++;
                        }
                    } else if (set[(index + offset) % initCap].key.equals(key)) {
                        Entry prevEntry = set[(index + offset) % initCap];
                        set[(index + offset) % initCap] = new Entry(key, value);
                        return prevEntry.value;
                    }
                    offset++;
                }
            }
        } else
            throw new IllegalStateException("Could not put another Entry; set full.");

        return null;
    }

    Object get(Object key) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null && set[index].key.equals(key) && !set[index].removed)
            return set[index].value;
        else {
            int offset = 1;

            while (set[(index + offset) % initCap] != null && index + offset < initCap) {
                if (!set[(index + offset) % initCap].removed && set[(index + offset) % initCap].key.equals(key)) {
                    return set[(index + offset) % initCap].value;
                }
                offset++;
            }
        }

        return null;
    }

    Object remove(Object key) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null && key.equals(set[index].key) && !set[index].removed) {
            set[index].removed = true;
            size--;
            return set[index].value;
        } else {
            int offset = 1;

            while (set[(index + offset) % initCap] != null && index + offset < initCap) {
                if (!set[(index + offset) % initCap].removed && set[(index + offset) % initCap].key.equals(key)) {
                    set[(index + offset) % initCap].removed = true;
                    size--;
                    return set[(index + offset) % initCap].value;
                }
                offset++;
            }
        }

        return null;
    }

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < initCap - 1; i++) {
            if (set[i] != null && !set[i].removed)
                str += set[i] + ", ";
            else
                str += "dummy, ";
        }
        if (set[set.length - 1] != null && !set[set.length - 1].removed)
            str += set[set.length - 1];
        else
            str += "dummy";

        return str;
    }
}

class Entry {
    public Object key, value;
    public boolean removed;

    Entry() {
        key = null;
        value = null;
        removed = false;
    }

    Entry(Object key, Object value) {
        this.key = key;
        this.value = value;
        removed = false;
    }

    @Override
    public String toString() {
        return "<" + key + ", " + value + ">";
    }
}

//-----------------------------------------------------------

class main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read;

        HashTable x = new HashTable();

        read = new Scanner(new File("1-put50items.txt"));
        for (int k = 0; k < 50; k++) {
            read.nextInt();
            read.next();

            int key = read.nextInt();
            String value = read.nextLine().trim();

            x.put(key, value);
        }

        read = new Scanner(new File("2-remove10items.txt"));
        for (int k = 0; k < 10; k++) {
            read.nextInt();
            read.next();

            int key = read.nextInt();
            read.nextLine();

            x.remove(key);
        }

        read = new Scanner(new File("3-put(overwriting)5items.txt"));
        for (int k = 0; k < 5; k++) {
            read.nextInt();
            read.next();

            int key = read.nextInt();
            String value = read.nextLine();

            x.put(key, value);
        }

        read = new Scanner(new File("4-put10items.txt"));
        for (int k = 0; k < 10; k++) {
            read.nextInt();
            read.next();

            int key = read.nextInt();
            String value = read.nextLine().trim();

            x.put(key, value);
        }

        System.out.println(x.toString());
    }
}