/*Kevin Paul, 4B, 12/2/19*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class HashTable {
    private int initCap;
    private Entry[] set;

    HashTable() {
        initCap = 101;
        set = new Entry[initCap];
    }

    HashTable(int initCap) {
        this.initCap = initCap;
        set = new Entry[initCap];
    }

    Object put(Object key, Object value) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null) {
            Object prevEntry = set[index];
            return prevEntry;
        }

        Entry newEntry = new Entry(key, value);
        set[index] = newEntry;
        return null;
    }

    Object get(Object key) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null)
            return set[index].value;
        return null;
    }

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < initCap - 1; i++)
            str += set[i] + ", ";
        str += set[set.length - 1];

        return str;
    }
}

class Entry {
    public Object key, value;

    Entry() {
        key = null;
        value = null;
    }

    Entry(Object key, Object value) {
        this.key = key;
        this.value = value;
    }

    @Override
    public String toString() {
        return "<" + key + ", " + value + ">";
    }
}

//-----------------------------------------------------------

class main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read = new Scanner(new File("data"));

        HashTable x = new HashTable();
        int count = 12;

        for (int k = 0; k < count; k++) {
            int key = read.nextInt();
            String value = read.nextLine().trim();

            x.put(key, value);
        }

        System.out.println(x.toString());
    }
}