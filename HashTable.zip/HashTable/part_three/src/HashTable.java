/*Kevin Paul, 4B, 1/3/19*/

import java.math.BigDecimal;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class HashTable {
    private int initCap, size = 0;
    private Entry[] set;

    long totalInsCollisions = 0, //total number of insertion collisions
            totalSsProbes = 0, //total number of successful search probes
            totalUnsSearchProbes = 0; //total number of unsuccessful search probes

    HashTable() {
        initCap = 101;
        set = new Entry[initCap];
    }

    HashTable(int initCap) {
        this.initCap = initCap;
        set = new Entry[initCap];
    }

    Object put(Object key, Object value) {
        int hc = key.hashCode(), index = hc % initCap;

        if (size < initCap) {
            if (set[index] == null) {
                set[index] = new Entry(key, value);
                size++;
                return null;
            } else if (set[index].removed) {
                Entry prevEntry = set[index];
                set[index] = new Entry(key, value);
                return prevEntry.value;
            } else if (set[index].key.equals(key)) {
                Object prevValue = set[index].value;
                set[index] = new Entry(key, value);
                return prevValue;
            } else { //collision occurs at calculated index
                int offset = 1;
                totalInsCollisions++;

                while (offset < initCap) {
                    if (set[(index + offset) % initCap] == null) {
                        set[(index + offset) % initCap] = new Entry(key, value);
                        size++;
                        return null;
                    } else if (set[(index + offset) % initCap].removed) {
                        set[(index + offset) % initCap] = new Entry(key, value);

                        offset++;
                        while (index + offset < initCap) {
                            if (set[(index + offset) % initCap] == null) {
                                size++;
                                return null;
                            } else if (set[(index + offset) % initCap].key.equals(key)) {
                                set[(index + offset) % initCap].removed = true;
                                return set[(index + offset) % initCap].value;
                            }
                            offset++;
                            totalInsCollisions++;
                        }
                    } else if (set[(index + offset) % initCap].key.equals(key)) {
                        Entry prevEntry = set[(index + offset) % initCap];
                        set[(index + offset) % initCap] = new Entry(key, value);
                        return prevEntry.value;
                    }
                    offset++;
                    totalInsCollisions++;
                }
            }
        } else
            throw new IllegalStateException("Could not put another Entry; set full.");

        return null;
    }

    Object get(Object key) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null && set[index].key.equals(key) && !set[index].removed)
            return set[index].value;
        else {
            int offset = 1;
            totalSsProbes++;
            totalUnsSearchProbes++;

            while (set[(index + offset) % initCap] != null && index + offset < initCap) {
                if (!set[(index + offset) % initCap].removed && set[(index + offset) % initCap].key.equals(key)) {
                    return set[(index + offset) % initCap].value;
                }
                offset++;
                totalSsProbes++;
                totalUnsSearchProbes++;
            }
        }

        return null;
    }

    Object remove(Object key) {
        int hc = key.hashCode(), index = hc % initCap;

        if (set[index] != null && key.equals(set[index].key) && !set[index].removed) {
            set[index].removed = true;
            size--;
            return set[index].value;
        } else {
            int offset = 1;

            while (set[(index + offset) % initCap] != null && index + offset < initCap) {
                if (!set[(index + offset) % initCap].removed && set[(index + offset) % initCap].key.equals(key)) {
                    set[(index + offset) % initCap].removed = true;
                    size--;
                    return set[(index + offset) % initCap].value;
                }
                offset++;
            }
        }

        return null;
    }

    public int size() {return size;}

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < initCap - 1; i++) {
            if (set[i] != null && !set[i].removed)
                str += set[i] + ", ";
            else
                str += "dummy, ";
        }
        if (set[set.length - 1] != null && !set[set.length - 1].removed)
            str += set[set.length - 1];
        else
            str += "dummy";

        return str;
    }
}

class Entry {
    public Object key, value;
    public boolean removed;

    Entry() {
        key = null;
        value = null;
        removed = false;
    }

    Entry(Object key, Object value) {
        this.key = key;
        this.value = value;
        removed = false;
    }

    @Override
    public String toString() {
        return "<" + key + ", " + value + ">";
    }
}

//-----------------------------------------------------------

class main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read = new Scanner(new File("store.txt"));
        //building ArrayLists
        ArrayList<String> dataSet = new ArrayList(500000);
        while (read.hasNext())
            dataSet.add(read.nextLine());
        read = new Scanner(new File("Successful Search.txt"));
        ArrayList<String> ssSet = new ArrayList(10000); //successful search set
        while (read.hasNext())
            ssSet.add(read.nextLine());
        read = new Scanner(new File("Unsuccessful Search.txt"));
        ArrayList<String> unSearchSet = new ArrayList(10000); //unsuccessful search set
        while (read.hasNext())
            unSearchSet.add(read.nextLine());
        read.close();

        int tableCap = 500000; //table capacity
        HashTable table = new HashTable(tableCap);
        long start, stop;

        /** insertion performance **/
        long totalInsertionTime = 0;

        for (int i = 0; i < dataSet.size(); i++) {
            start = System.currentTimeMillis();
            Object[] entry = parse(dataSet.get(i)); //parse() is at the very bottom
            table.put(Integer.parseInt(entry[0] + ""), entry[1]);
            stop = System.currentTimeMillis();
            long insertionTime = stop - start;
            totalInsertionTime += insertionTime;
        }
        double avgInsertionTime = ((double) totalInsertionTime) / dataSet.size();

        /** successful search performance **/
        long totalSsTime = 0; //total successful search time

        for (int i = 0; i < ssSet.size(); i++) {
            start = System.currentTimeMillis(); //successful search start
            Object[] entry = parse(ssSet.get(i));
            table.get(Integer.parseInt(entry[0] + ""));
            stop = System.currentTimeMillis();
            long sSTime = stop - start;
            totalSsTime += sSTime;
        }
        double avgSsTime = ((double) totalSsTime) / ssSet.size();
        double avgSsProbes = ((double) table.totalSsProbes) / ssSet.size();

        /** unsuccessful search performance **/
        table.totalUnsSearchProbes = 0; //needs to be reset at this point
        long totalUnsSearchTime = 0L;

        for (int i = 0; i < unSearchSet.size(); i++) {
            start = System.currentTimeMillis(); //unsuccessful search start
            Object[] entry = parse(unSearchSet.get(i));
            table.get(Integer.parseInt(entry[0] + ""));
            stop = System.currentTimeMillis();
            long unsSearchTime = stop - start;
            totalUnsSearchTime += unsSearchTime;
        }
        double avgUnsSearchTime = ((double) totalUnsSearchTime) / unSearchSet.size();
        BigDecimal avgUnsSearchProbes = BigDecimal.valueOf(((double) table.totalUnsSearchProbes) / unSearchSet.size());

        System.out.println("Type of hashing used - linear probing\n"
                + "Hash function used - Integer value\n"
                + "Number of records added to table: " + table.size() + "\n"
                + "Capacity of table: " + tableCap + "\n"
                + "Load factor: " + (double) table.size() / tableCap + "\n"
                + "Average insertion time: " + avgInsertionTime + " ms\n"
                + "Number of table insertion collisions: " + table.totalInsCollisions + "\n"
                + "Number of collisions vs. number of insertions: " + ((double) table.totalInsCollisions) / dataSet.size() * 100 + "%\n"
                + "Average time to find table entry: " + avgSsTime + " ms\n"
                + "Average number of probes needed to find table entry: " + avgSsProbes + "\n"
                + "Average time to determine that entry is not in table: " + avgUnsSearchTime + " ms\n"
                + "Average number of probes needed to determine that entry is not in table: " + avgUnsSearchProbes);
    }
    //----------------------------------------------------------------
    static Object[] parse(String line) {
        String[] parts = line.split(" ");
        Object[] entry = new Object[2];
        entry[0] = parts[0];
        entry[1] = parts[1] + " " + parts[2];
        return entry;
    }
}