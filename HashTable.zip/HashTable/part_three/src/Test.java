import java.math.BigDecimal;

public class Test {
    public static void main(String[] args) {
        double a = 578;
        double b = 500000;
        double total = a / b;
        System.out.println(total);
    }
}
