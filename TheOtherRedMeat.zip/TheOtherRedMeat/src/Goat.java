/*Kevin Paul, 4B*/

import java.util.PriorityQueue;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

class main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read = new Scanner(new File("goat.dat"));

        int cases = read.nextInt();
        read.nextLine();
        for (int c = 0; c < cases; c++) {
            ArrayList<Goat> goats = new ArrayList();

            int num = read.nextInt();
            for (int n = 0; n < num; n++) {
                String[] temp = read.nextLine().split(" ");
                int[] milk = new int[num];
                for (int i = 0; i < temp.length; i++)
                    milk[i] = Integer.parseInt(temp[i]);
                goats.add(new Goat(milk));
            }

            //At this point, goats has all Goat objects


        }
    }
}

class Goat implements Comparable<Goat> {
    int[] milk;
    private int currentMilk;

    public Goat(int[] milk) {
        this.milk = milk;
        currentMilk = milk[0];
    }

    public int getMilkOfDay(int day) { //day = 1 --> 1st day
        return milk[(day - 1) % milk.length];
    }

    public void setCurrentMilk(int day) {
        currentMilk = milk[(day - 1) % milk.length];
    }

    public int getCurrentMilk() {
        return currentMilk;
    }

    @Override
    public int compareTo(Goat other) {
        return this.getCurrentMilk() - other.getCurrentMilk();
    }
}