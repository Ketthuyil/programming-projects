import java.util.PriorityQueue;

public class Test {
    public static void main(String[] args) {
        PriorityQueue asd = new PriorityQueue();

        asd.add(3);
        asd.add(1);
        asd.add(2);
        asd.add(1);
        System.out.println(asd.poll());
    }
}
