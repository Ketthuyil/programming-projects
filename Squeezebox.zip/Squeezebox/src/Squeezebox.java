/*Kevin Paul, 11/21/19, 4B*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Squeezebox {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read = new Scanner(new File("squeezebox.dat"));

        String line = read.nextLine();
        while (!line.equals("#")) {
            LinkedList piles = new LinkedList();

            for (int k = 0; k < 2; k++) {
                String[] cards = line.split(" ");
                for (int i = 0; i < 26; i++) {
                    LinkedList pile = new LinkedList();
                    pile.addToFront(cards[i]);
                    piles.addToBack(pile);
                }

                if (k == 0)
                    line = read.nextLine();
            }

            //at this point, piles should have all 52 pile LinkedList stacks (ea. having a single String card)


            for (int k = 1; k < piles.size(); k++) { //k --> first card to compare with
                String selectedCard = (String) ((LinkedList) piles.get(k)).get(0),
                        cardThreeToLeft = "",
                        cardToLeft = (String) ((LinkedList) piles.get(k - 1)).get(0);

                if (k >= 3) {
                    cardThreeToLeft = (String) ((LinkedList) piles.get(k - 3)).get(0);
                }

                if (k >= 3 && areCardsEqual(selectedCard, cardThreeToLeft)) {
                    ((LinkedList) piles.get(k)).removeFromFront();
                    ((LinkedList) piles.get(k - 3)).addToFront(selectedCard);

                    if (((LinkedList) piles.get(k)).get(0) == null)
                        piles.remove(k);
                    k = 0;
                } else if (areCardsEqual(selectedCard, cardToLeft)) {
                    ((LinkedList) piles.get(k)).removeFromFront();
                    ((LinkedList) piles.get(k - 1)).addToFront(selectedCard);

                    if (((LinkedList) piles.get(k)).get(0) == null)
                        piles.remove(k);
                    k = 0;
                }
            }

            if (piles.size() > 1)
                System.out.print(piles.size() + " piles remaining: ");
            else
                System.out.print("1 pile remaining: ");

            for (int i = 0; i < piles.size(); i++)
                System.out.print(((LinkedList) piles.get(i)).size() + " ");
            System.out.println();

            line = read.nextLine();
        }
    }

    static boolean areCardsEqual(String cardOne, String cardTwo) {
        String cardOneRank = cardOne.substring(0, 1), cardOneSuit = cardOne.substring(1, 2);
        String cardTwoRank = cardTwo.substring(0, 1), cardTwoSuit = cardTwo.substring(1, 2);

        if (cardOneRank.equals(cardTwoRank) || cardOneSuit.equals(cardTwoSuit))
            return true;
        else
            return false;
    }
}
