/*Kevin Paul, 4B, 10/19/19*/

public class LinkedList {
    private Node head;
    private int count;

    LinkedList() {
        head = null;
        count = 0;
    }

    //Adds an Object to the beginning of the list
    void addToFront(Object data) {
        Node newHead = new Node(data);
        Node prevHead = head;
        newHead.setNextNode(prevHead);
        head = newHead;
        count++;
    }

    //Adds an Object to the end of the list
    void addToBack(Object data) {
        Node newNode = new Node(data);
        Node current = head;
        count++;
        if (head == null)
            head = newNode;
        else
            for (int i = 0; i < count; i++) {
                if (current.getNextNode() == null) {
                    current.setNextNode(newNode);
                    break;
                }
                current = (Node) current.getNextNode();
            }
    }

    Object get(int index) {
        Node current = head;
        int cIndex = 0;
        while (current != null) {
            if (cIndex == index)
                return current.get();
            current = (Node) current.getNextNode();
            cIndex++;
        }
        return null;
    }

    void addBefore(int index, Object data) {
        if (index == 0) {
            Node newNode = new Node(data);
            newNode.setNextNode(head);
        } else if (index >= 0 && index < count) {
            Node current = head;
            for (int i = 0; i < count; i++) {
                if (i == index - 1) {
                    Node nextNode = (Node) current.getNextNode();
                    Node newNode = new Node(data);
                    newNode.setNextNode(nextNode);
                    current.setNextNode(newNode);
                    count++;
                }
                current = (Node) current.getNextNode();
            }
        }
    }

    Object remove(int index) {
        Node target = head;
        if (index == 0) {
            if (count > 1)
                head = (Node) head.getNextNode();
            else
                head = new Node();
            count--;
        } else if (index >= 0 && index < count) {
            Node current = head;
            for (int i = 0; i < count; i++) {
                if (i == index - 1) {
                    target = (Node) current.getNextNode();
                    current.setNextNode((Node) target.getNextNode());
                    count--;
                    break;
                }
                current = (Node) current.getNextNode();
            }
        }
        return target;
    }

    //removes from the front of the LinkedList
    Object removeFromFront() {
        Node removedHead = head;

        if (count > 1)
            head = (Node) removedHead.getNextNode();
        else
            head = new Node();
        count--;
        return removedHead;
    }

    int size() { return count; }

    @Override
    public String toString() {
        String str = "{";

        Node current = head;
        for (int i = 0; i < count - 1; i++) {
            str += current.get() + ", ";
            current = (Node) current.getNextNode();
        }
        str += current.get() + "}";

        return str;
    }
}