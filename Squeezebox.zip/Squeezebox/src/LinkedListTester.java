public class LinkedListTester {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.addToBack("a");
        list.addToBack(15);
        list.addToBack(true);

        System.out.println(list);

        list.addBefore(1, 'b');

        System.out.println(list.size());
        System.out.println(list);

        System.out.println(list.remove(3));
        System.out.println(list.size());

        System.out.println(list.removeFromFront());
        System.out.println(list.size());

        list.addToBack(5.6667);
        System.out.println(list.size());
        System.out.println(list);
    }
}
