/** Kevin Paul, 4B*/

public class Couple {
    String name1, name2;
    int hd1, hd2;

    public Couple (String name1, String name2, Integer hd1, Integer hd2) {
        this.name1 = name1;
        this.name2 = name2;
        this.hd1 = hd1;
        this.hd2 = hd2;
    }
}