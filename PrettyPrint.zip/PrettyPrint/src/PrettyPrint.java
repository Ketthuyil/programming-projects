/*Kevin Paul, 4B*/

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

public class PrettyPrint {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner read = new Scanner(new File("prettyprint.dat"));

        BinaryTree tree = new BinaryTree(3);

    }
}

class BinaryTree {
    Node overallRoot;
    int size;

    public BinaryTree() {
        overallRoot = null;
    }

    public BinaryTree(double overallRoot) {
        this.overallRoot = new Node(overallRoot);
        size++;
    }

    public void insert(double value) {
        if (overallRoot == null) {
            overallRoot = new Node(value);
            size++;
            return;
        }

        Node parent = findParent(value, overallRoot);
        if (value <= parent.value) {
            if (parent.leftNode == null) {
                parent.setLeft(value);
                size++;
            } else
                System.out.println("There has been a mistake.");
        }
        else {
            if (parent.rightNode == null) {
                parent.setRight(value);
                size++;
            } else
                System.out.println("There has been a mistake.");
        }
    }

    public Node findParent(double newValue, Node root) {
        if (newValue <= root.value && root.leftNode == null)
            return root;
        else if (newValue > root.value && root.rightNode == null)
            return root;
        else {
            if (newValue <= root.value)
                return findParent(newValue, root.leftNode);
            else
                return findParent(newValue, root.rightNode);
        }
    }

    public int size() { return size; }
}

class Node {
    double value;
    Node leftNode, rightNode;
    int level;

    public Node() {
        value = 0;
        leftNode = null;
        rightNode = null;
        level = 0;
    }

    public Node(double value) {
        this.value = value;
        leftNode = null;
        rightNode = null;
        level = 0;
    }

    public Node(double value, Node leftNode, Node rightNode) {
        this.value = value;
        this.leftNode = leftNode;
        this.rightNode = rightNode;
        level = 0;
    }

    public void setLeft(double value) { leftNode = new Node(value); }

    public void setRight(double value) { rightNode = new Node(value); }
}